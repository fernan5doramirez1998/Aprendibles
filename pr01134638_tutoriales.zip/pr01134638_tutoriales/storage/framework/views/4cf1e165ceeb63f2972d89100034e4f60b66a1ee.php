<?php $__env->startSection('contenido'); ?>
    <h1>Mensaje</h1>
    <p>Enviado por <?php echo e($message->nombre); ?> - <?php echo e($message->email); ?></p>
    <p><?php echo e($message->mensaje); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>