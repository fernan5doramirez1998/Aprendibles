<?php $__env->startSection('contenido'); ?>
<h1>Saludos a <?php echo e($nombre); ?></h1>
<ul>
    <?php $__empty_1 = true; $__currentLoopData = $consolas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li><?php echo e($consola); ?></li>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No hay consolas. :(</p>
        
    <?php endif; ?>
</ul>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>