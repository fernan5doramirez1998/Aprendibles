<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
    .active{
        text-decoration: none;
        color: green;
        }

    .error{
         color: red;
         font-size: 12px;
        }

    </style>

    
    <title>Mi sitio</title>
</head>
<body>
    <header>
        <?php function activeMenu($url)
        {
            return request()->is($url) ? 'active' : '';
        } ?>
        
        <nav>
            <a class="<?php echo e(activeMenu('/')); ?>" href="<?php echo e(route('home')); ?>">Inicio</a>
            <a class="<?php echo e(activeMenu('saludos*')); ?>" href="<?php echo e(route('saludos', 'Fernando')); ?>">Saludo</a>
            <a class="<?php echo e(activeMenu('mensajes/create')); ?>" href="<?php echo e(route('mensajes.create')); ?>">Contactos</a>
            <?php if(auth()->check()): ?>
                <a class="<?php echo e(activeMenu('mensajes')); ?>" href="<?php echo e(route('mensajes.index')); ?>">Mensajes</a>
                <a href="/logout">Cerrar sesión de <?php echo e(auth()->user()->name); ?></a>
            <?php endif; ?>
                       
            <?php if(auth()->guest()): ?>
                <a class="<?php echo e(activeMenu('login')); ?>" href="/login">Login</a>    
            <?php endif; ?>
            
        </nav>
    </header>
</body>
<?php echo $__env->yieldContent('contenido'); ?>
<footer>Copyright ° <?php echo e(date('Y')); ?></footer>
</html>