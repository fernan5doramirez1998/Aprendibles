<?php $__env->startSection('contenido'); ?>
    <h1>Contactos</h1>
    <h1>Escríbeme.</h1>
    <?php if(session()->has('info')): ?>
        <h3><?php echo e(session('info')); ?></h3>
    <?php else: ?>
    
    <form action="contacto" method="POST">
        <?php echo csrf_field(); ?>

    
        <p><label for="nombre">
            Nombre
            <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>">
            <?php echo $errors->first('nombre', '<span class=error>:message</span>'); ?>

        </label></p>

        <p><label for="email">
            Email
            <input type="text" name="email" value="<?php echo e(old('email')); ?>">
            <?php echo $errors->first('email', '<span class=error>:message</span>'); ?>

        </label></p>

        <p><label for="mensaje">
            Mensaje
            <textarea name="mensaje" value="<?php echo e(old('mensaje')); ?>"></textarea>
            <?php echo $errors->first('mensaje', '<span class=error>:message</span>'); ?>

        </label></p>

        <input type="submit" value="Enviar">

    </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>