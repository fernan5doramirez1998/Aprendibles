<?php $__env->startSection('contenido'); ?>
    
<h1>Editar mensaje</h1>
<form action="<?php echo e(route('mensajes.update', $message->id)); ?>" method="POST">
        <?php echo method_field('PUT'); ?>

        <?php echo csrf_field(); ?>

    
        <p><label for="nombre">
            Nombre
            <input type="text" name="nombre" value="<?php echo e($message->nombre); ?>">
            <?php echo $errors->first('nombre', '<span class=error>:message</span>'); ?>

        </label></p>

        <p><label for="email">
            Email
            <input type="text" name="email" value="<?php echo e($message->email); ?>">
            <?php echo $errors->first('email', '<span class=error>:message</span>'); ?>

        </label></p>

        <p><label for="mensaje">
            Mensaje
            <textarea name="mensaje"><?php echo e($message->mensaje); ?></textarea>
            <?php echo $errors->first('mensaje', '<span class=error>:message</span>'); ?>

        </label></p>

        <input type="submit" value="Enviar">

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>