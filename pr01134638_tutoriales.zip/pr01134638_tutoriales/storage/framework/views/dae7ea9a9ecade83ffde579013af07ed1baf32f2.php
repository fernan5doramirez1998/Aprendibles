<?php $__env->startSection('contenido'); ?>
    <h1>Todos los mensajes</h1>
    <table width="100%" border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Mensaje</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($message->id); ?></td>

                <td>
                    <a href="<?php echo e(route('mensajes.show', $message->id)); ?>">
                        <?php echo e($message->nombre); ?>

                    </a>
                </td>
                <td><?php echo e($message->email); ?></td>
                <td><?php echo e($message->mensaje); ?></td>
                <td>
                    <a href="<?php echo e(route('mensajes.edit', $message->id)); ?>">Editar</a>
                    <form style="display: inline" method="POST" action="<?php echo e(route('mensajes.destroy', $message->id)); ?>">
                        <?php echo csrf_field(); ?>

                        <?php echo method_field('DELETE'); ?>

                        <button type="submit">Eliminar</button>
                    </form>
                </td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>