<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Error</title>
</head>
<body>
	<h1>No pudimos encontrar esta página.</h1>
	<a href="{{ route('home') }}">Regresar al home</a>

</body>
</html>