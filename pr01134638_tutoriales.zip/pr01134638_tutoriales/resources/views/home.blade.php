@extends('layout')

@section('contenido')
    <h1>Home</h1>
@stop